import boto3

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    
    file_content = 'hellooooo, this is testing new testing'
    bucket_name = 'buhbhkcketritik8338123'
    key_name = 'data/test.txt'
    
    try:
        response = s3.put_object(
            Bucket=bucket_name,
            Key=key_name,
            ACL='bucket-owner-full-control',
            Body=file_content,
            ContentEncoding='utf-8'
        )
        print('Successfully uploaded file to S3')
    except Exception as e:
        print('Error: ', e)
