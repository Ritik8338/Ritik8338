import boto3

def lambda_handler(event, context):
    # Initialize the SageMaker client
    sm_client = boto3.client('sagemaker')
    
    # Your code logic here that uses the 'sm_client' to interact with SageMaker services
    # For example, you can create a model package group using the 'sm_client' like this:
    model_package_group_name = "testGroup"
    
    # Create the Model Package Group
    create_model_package_group_response = sm_client.create_model_package_group(
        ModelPackageGroupName=model_package_group_name,
        ModelPackageGroupDescription="My Model Package Group Description"
    )
    
    # Print the response (optional)
    print(create_model_package_group_response)

    model_url = "s3://sagemaker-us-west-2-575773971780/sagemaker-scikit-learn-2023-07-27-04-43-23-834/output/model.tar.gz"
    
    modelpackage_inference_specification = {
        "InferenceSpecification": {
            "Containers": [
                {
                    "Image": '246618743249.dkr.ecr.us-west-2.amazonaws.com/sagemaker-scikit-learn:0.20.0-cpu-py3',
                    "ModelDataUrl": model_url
                }
            ],
            "SupportedContentTypes": ["text/csv"],
            "SupportedResponseMIMETypes": ["text/csv"],
        }
    }

    create_model_package_input_dict = {
        "ModelPackageGroupName": model_package_group_name,
        "ModelPackageDescription": "Model to detect 3 different types of irises (Setosa, Versicolour, and Virginica)",
        "ModelApprovalStatus": "PendingManualApproval"
    }
    
    create_model_package_input_dict.update(modelpackage_inference_specification)
    
    # Now you can use the 'sm_client' to create the model package group
    response = sm_client.create_model_package(**create_model_package_input_dict)
    
    return {
        "statusCode": 200,
        "body": "Model package group created successfully!",
        "response": response
    }
